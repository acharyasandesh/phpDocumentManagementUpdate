<?php 
echo "Welcome to Dilitrust!";
?>