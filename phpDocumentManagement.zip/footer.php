<div id = "footer">
		<label class = "footer-title">&copy; Sandesh Document Management System <?php echo date("Y")?><span class="footer-author">By Sandesh Acharya</span></label>
</div>
</body>
</html>