<?php include 'head.php'?>
<?php include 'login.php'?>
<?php include 'footer.php'?>

<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} ?>