<?php
	session_start();
	require 'conn.php';
	require_once 'csrfProtection.php';
	
	if(ISSET($_POST['login'])){
		$username = trim(addslashes(mysqli_real_escape_string($conn, $_POST['username'])));
		$password = trim(addslashes(mysqli_real_escape_string($conn, md5($_POST['password']))));
		
		$query = mysqli_query($conn, "SELECT * FROM `users` WHERE `username` = '$username' && `password` = '$password'") or die(mysqli_error($conn));
		$fetch = mysqli_fetch_array($query);
		$row = $query->num_rows;
		
		if($row > 0){
			$_SESSION['users'] = $fetch['username'];
			header("location:user_profile.php");
		}else{
			$errorMessage= "<center><label class='text-danger'>Invalid username or password</label></center>";
			include 'main.php';
		}
	}
?>